<p class="text-center"><img src="{{ asset('assets/etc/no-data-found.png') }}" alt="No Data Found"></p>
